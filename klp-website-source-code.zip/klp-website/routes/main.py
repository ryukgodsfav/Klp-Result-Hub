"""
Main public-facing routes for the KLP Roorkee website.
Handles: Home page, About, Departments, Sports, Courses, and Contact.
"""

from flask import Blueprint, render_template

# Blueprint for all public pages
main_bp = Blueprint('main', __name__)


# ─── Home Page ────────────────────────────────────────────────────────────────

@main_bp.route('/')
def home():
    """Render the main landing page with college info, departments, hiring partners, etc."""

    # Hiring partner companies (displayed in a slider on the homepage)
    hiring_partners = [
        {"name": "TATA Group", "sector": "Manufacturing & Engineering"},
        {"name": "Maruti Suzuki", "sector": "Automobile"},
        {"name": "HCL Technologies", "sector": "Information Technology"},
        {"name": "Hero MotoCorp", "sector": "Automobile"},
        {"name": "Saraswati Dynamic Ltd.", "sector": "Engineering"},
        {"name": "Simple Infrastructure", "sector": "Construction"},
        {"name": "Lloyd Insulation Ltd.", "sector": "Insulation & Construction"},
        {"name": "Bajaj Auto", "sector": "Automobile"},
        {"name": "Kirby Building Systems", "sector": "Steel Buildings"},
        {"name": "ABB Ltd.", "sector": "Electrical & Automation"},
        {"name": "Kenwood", "sector": "Electronics"},
        {"name": "VIP Luggage Ltd.", "sector": "Manufacturing"},
        {"name": "TVS Ltd.", "sector": "Automobile"},
    ]

    # Department list with descriptions
    departments = [
        {
            "name": "Civil Engineering",
            "code": "CE",
            "icon": "🏗️",
            "desc": "Construction, structural design, and infrastructure development.",
            "seats": 60
        },
        {
            "name": "Mechanical Engineering",
            "code": "ME",
            "icon": "⚙️",
            "desc": "Machines, thermodynamics, manufacturing, and industrial processes.",
            "seats": 60
        },
        {
            "name": "Electrical Engineering",
            "code": "EE",
            "icon": "⚡",
            "desc": "Power systems, circuits, motors, and electrical installation.",
            "seats": 60
        },
        {
            "name": "Electronics Engineering",
            "code": "EN",
            "icon": "📡",
            "desc": "Electronic circuits, communication systems, and embedded tech.",
            "seats": 60
        },
        {
            "name": "AI & Machine Learning",
            "code": "AIML",
            "icon": "🤖",
            "desc": "Artificial intelligence, data science, and machine learning applications.",
            "seats": 60
        },
        {
            "name": "Computer Communication & Networking",
            "code": "CCN",
            "icon": "🌐",
            "desc": "Networking protocols, cybersecurity, and IT infrastructure.",
            "seats": 60
        },
    ]

    # Sports events / activities at KLP
    sports_events = [
        {
            "name": "Annual Sports Day",
            "type": "Annual Event",
            "icon": "🏆",
            "desc": "Grand annual sports celebration with athletics, team games, and individual events. Held every year with prize distribution ceremony and cultural performances.",
            "highlights": ["Athletics (100m, 200m, 400m)", "Volleyball", "Basketball", "Cricket", "Tug of War", "Badminton"]
        },
        {
            "name": "Zonal Sports Competition",
            "type": "Inter-College",
            "icon": "🥇",
            "desc": "Inter-college zonal competition organized by UBTER. KLP students participate and represent the college at regional level in multiple sports disciplines.",
            "highlights": ["Inter-College Football", "Kabaddi", "Table Tennis", "Chess", "Athletics", "Hockey"]
        },
    ]

    return render_template(
        'home.html',
        departments=departments,
        hiring_partners=hiring_partners,
        sports_events=sports_events
    )


# ─── About Page (optional extra route) ───────────────────────────────────────

@main_bp.route('/about')
def about():
    """Render the about/college details page."""
    return render_template('home.html')  # Scroll to about section on homepage
