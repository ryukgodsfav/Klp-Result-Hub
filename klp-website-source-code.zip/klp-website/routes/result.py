"""
Student Result routes.
Students can look up their result by entering a roll number or enrollment number.
Results display all subject marks, SGPA, CGPA, and can be downloaded as PDF.
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from models import Student, Subject
import io

# Blueprint for result-related pages
result_bp = Blueprint('result', __name__, url_prefix='/result')


# ─── Result Lookup Page ───────────────────────────────────────────────────────

@result_bp.route('/', methods=['GET', 'POST'])
def result_home():
    """
    GET  → Show the roll number input form.
    POST → Look up the student and redirect to result display.
    """
    if request.method == 'POST':
        query = request.form.get('roll_number', '').strip()

        if not query:
            flash('Please enter your Roll Number or Enrollment Number.', 'warning')
            return redirect(url_for('result.result_home'))

        # Search by roll number OR enrollment number (case-insensitive)
        student = Student.query.filter(
            (Student.roll_number.ilike(query)) |
            (Student.enrollment_no.ilike(query))
        ).first()

        if student:
            # Redirect to the individual result page
            return redirect(url_for('result.show_result', student_id=student.id))
        else:
            flash(f'No result found for: {query}. Please check your Roll Number / Enrollment Number.', 'danger')
            return redirect(url_for('result.result_home'))

    # GET request — show the search form
    return render_template('result_search.html')


# ─── Display Individual Result ────────────────────────────────────────────────

@result_bp.route('/show/<int:student_id>')
def show_result(student_id):
    """
    Display the full marksheet for a student.
    Shows theory subjects, practical subjects, SGPA, CGPA, and semester result.
    """
    student = Student.query.get_or_404(student_id)

    # Separate theory and practical subjects for display
    theory_subjects    = [s for s in student.subjects if s.subject_type == 'Theory']
    practical_subjects = [s for s in student.subjects if s.subject_type == 'Practical']

    # Calculate totals
    theory_total_max      = sum(s.max_marks     for s in theory_subjects)
    theory_total_obtained = sum(s.marks_obtained for s in theory_subjects)
    practical_total_max      = sum(s.max_marks     for s in practical_subjects)
    practical_total_obtained = sum(s.marks_obtained for s in practical_subjects)
    grand_total_max      = theory_total_max      + practical_total_max
    grand_total_obtained = theory_total_obtained + practical_total_obtained

    return render_template(
        'result_display.html',
        student=student,
        theory_subjects=theory_subjects,
        practical_subjects=practical_subjects,
        theory_total_max=theory_total_max,
        theory_total_obtained=theory_total_obtained,
        practical_total_max=practical_total_max,
        practical_total_obtained=practical_total_obtained,
        grand_total_max=grand_total_max,
        grand_total_obtained=grand_total_obtained
    )


# ─── Download PDF Marksheet ───────────────────────────────────────────────────

@result_bp.route('/download/<int:student_id>')
def download_pdf(student_id):
    """
    Generate and download a PDF marksheet for the student.
    Uses ReportLab to create a formatted PDF in memory and serve it.
    """
    student = Student.query.get_or_404(student_id)

    theory_subjects    = [s for s in student.subjects if s.subject_type == 'Theory']
    practical_subjects = [s for s in student.subjects if s.subject_type == 'Practical']

    # Build the PDF in memory using ReportLab
    pdf_buffer = generate_marksheet_pdf(student, theory_subjects, practical_subjects)

    # Serve the PDF as a file download
    filename = f"Marksheet_{student.roll_number}_{student.name.replace(' ', '_')}.pdf"
    return send_file(
        pdf_buffer,
        mimetype='application/pdf',
        as_attachment=True,
        download_name=filename
    )


# ─── PDF Generation Helper ────────────────────────────────────────────────────

def generate_marksheet_pdf(student, theory_subjects, practical_subjects):
    """
    Generate a professional PDF marksheet using ReportLab.
    Returns a BytesIO buffer containing the PDF data.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate, Table, TableStyle, Paragraph,
        Spacer, HRFlowable
    )
    from reportlab.lib.enums import TA_CENTER, TA_LEFT

    buffer = io.BytesIO()

    # Create PDF document with A4 size and margins
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=1.5*cm,
        leftMargin=1.5*cm,
        topMargin=1.5*cm,
        bottomMargin=1.5*cm
    )

    styles = getSampleStyleSheet()
    story  = []  # List of flowable elements for the PDF

    # ── Custom styles ──────────────────────────────────────────────────────
    title_style = ParagraphStyle(
        'Title',
        parent=styles['Normal'],
        fontSize=16,
        fontName='Helvetica-Bold',
        alignment=TA_CENTER,
        textColor=colors.HexColor('#1a237e'),
        spaceAfter=4
    )
    subtitle_style = ParagraphStyle(
        'Subtitle',
        parent=styles['Normal'],
        fontSize=11,
        fontName='Helvetica-Bold',
        alignment=TA_CENTER,
        textColor=colors.HexColor('#283593'),
        spaceAfter=2
    )
    small_center = ParagraphStyle(
        'SmallCenter',
        parent=styles['Normal'],
        fontSize=9,
        alignment=TA_CENTER,
        textColor=colors.HexColor('#555555'),
        spaceAfter=2
    )
    label_style = ParagraphStyle(
        'Label',
        parent=styles['Normal'],
        fontSize=9,
        fontName='Helvetica-Bold'
    )
    value_style = ParagraphStyle(
        'Value',
        parent=styles['Normal'],
        fontSize=9,
        fontName='Helvetica'
    )

    # ── College Header ─────────────────────────────────────────────────────
    story.append(Paragraph("KANHAIYA LAL POLYTECHNIC ROORKEE (KLP)", title_style))
    story.append(Paragraph("Affiliated to Uttarakhand Board of Technical Education (UBTER), Roorkee", subtitle_style))
    story.append(Paragraph("Affiliated & Recognized by All India Council for Technical Education (AICTE)", small_center))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#1a237e')))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph("SEMESTER MARKSHEET", ParagraphStyle(
        'SheetTitle',
        parent=styles['Normal'],
        fontSize=13,
        fontName='Helvetica-Bold',
        alignment=TA_CENTER,
        textColor=colors.HexColor('#c62828'),
        spaceAfter=6
    )))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#1a237e')))
    story.append(Spacer(1, 0.3*cm))

    # ── Student Information Table ──────────────────────────────────────────
    info_data = [
        ["Student Name:", student.name,                  "Roll Number:", student.roll_number],
        ["Enrollment No:", student.enrollment_no,         "Father's Name:", student.father_name],
        ["Branch:", student.branch,                      "Category:", student.category],
        ["Institution:", student.institution,             "Semester:", f"Semester {student.semester}"],
        ["Academic Year:", student.academic_year,         "", ""],
    ]

    info_table = Table(info_data, colWidths=[3.5*cm, 5.5*cm, 3.5*cm, 5.5*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#1a237e')),
        ('TEXTCOLOR', (2, 0), (2, -1), colors.HexColor('#1a237e')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.HexColor('#f3f4f6'), colors.white]),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#cccccc')),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 0.4*cm))

    # ── Theory Subjects Table ──────────────────────────────────────────────
    if theory_subjects:
        story.append(Paragraph("THEORY SUBJECTS", ParagraphStyle(
            'SectionHead',
            parent=styles['Normal'],
            fontSize=10,
            fontName='Helvetica-Bold',
            textColor=colors.white,
            backColor=colors.HexColor('#1a237e'),
            leftIndent=4,
            spaceAfter=0
        )))

        th_header = [["S.No", "Subject Code", "Subject Name", "Max Marks", "Marks Obtained", "Grade", "Result"]]
        th_rows = []
        for i, s in enumerate(theory_subjects, 1):
            th_rows.append([
                str(i), s.subject_code, s.subject_name,
                str(s.max_marks), str(s.marks_obtained),
                s.grade or "-", s.result or "-"
            ])
        # Total row
        th_total_max = sum(s.max_marks for s in theory_subjects)
        th_total_obt = sum(s.marks_obtained for s in theory_subjects)
        th_rows.append(["", "TOTAL", "", str(th_total_max), str(th_total_obt), "", ""])

        th_data = th_header + th_rows
        th_table = Table(th_data, colWidths=[1*cm, 2.5*cm, 5.5*cm, 2*cm, 2.5*cm, 1.5*cm, 1.5*cm])
        th_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a237e')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('ALIGN', (2, 0), (2, -1), 'LEFT'),
            ('ROWBACKGROUNDS', (0, 1), (-1, -2), [colors.white, colors.HexColor('#e8eaf6')]),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#c5cae9')),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#9fa8da')),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        story.append(th_table)
        story.append(Spacer(1, 0.3*cm))

    # ── Practical Subjects Table ───────────────────────────────────────────
    if practical_subjects:
        story.append(Paragraph("PRACTICAL SUBJECTS", ParagraphStyle(
            'SectionHead2',
            parent=styles['Normal'],
            fontSize=10,
            fontName='Helvetica-Bold',
            textColor=colors.white,
            backColor=colors.HexColor('#1b5e20'),
            leftIndent=4,
            spaceAfter=0
        )))

        pr_header = [["S.No", "Subject Code", "Subject Name", "Max Marks", "Marks Obtained", "Grade", "Result"]]
        pr_rows = []
        for i, s in enumerate(practical_subjects, 1):
            pr_rows.append([
                str(i), s.subject_code, s.subject_name,
                str(s.max_marks), str(s.marks_obtained),
                s.grade or "-", s.result or "-"
            ])
        pr_total_max = sum(s.max_marks for s in practical_subjects)
        pr_total_obt = sum(s.marks_obtained for s in practical_subjects)
        pr_rows.append(["", "TOTAL", "", str(pr_total_max), str(pr_total_obt), "", ""])

        pr_data = pr_header + pr_rows
        pr_table = Table(pr_data, colWidths=[1*cm, 2.5*cm, 5.5*cm, 2*cm, 2.5*cm, 1.5*cm, 1.5*cm])
        pr_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1b5e20')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('ALIGN', (2, 0), (2, -1), 'LEFT'),
            ('ROWBACKGROUNDS', (0, 1), (-1, -2), [colors.white, colors.HexColor('#e8f5e9')]),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#c8e6c9')),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#a5d6a7')),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        story.append(pr_table)
        story.append(Spacer(1, 0.3*cm))

    # ── Result Summary Box ─────────────────────────────────────────────────
    grand_total_max = sum(s.max_marks for s in theory_subjects + practical_subjects)
    grand_total_obt = sum(s.marks_obtained for s in theory_subjects + practical_subjects)

    result_color = colors.HexColor('#1b5e20') if student.semester_result == 'PASS' else colors.HexColor('#b71c1c')

    summary_data = [
        ["Grand Total:", f"{grand_total_obt} / {grand_total_max}",
         "Percentage:", f"{(grand_total_obt/grand_total_max*100):.2f}%" if grand_total_max > 0 else "N/A"],
        ["SGPA:", str(student.sgpa or "N/A"),
         "CGPA:", str(student.cgpa or "N/A")],
        ["Semester Result:", student.semester_result or "N/A", "", ""],
    ]
    summary_table = Table(summary_data, colWidths=[3.5*cm, 4*cm, 3.5*cm, 7*cm])
    summary_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#1a237e')),
        ('TEXTCOLOR', (2, 0), (2, -1), colors.HexColor('#1a237e')),
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#e3f2fd')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#90caf9')),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('SPAN', (1, 2), (3, 2)),
        ('TEXTCOLOR', (1, 2), (1, 2), result_color),
        ('FONTNAME', (1, 2), (1, 2), 'Helvetica-Bold'),
        ('FONTSIZE', (1, 2), (1, 2), 11),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 0.6*cm))

    # ── Footer / Signature Block ───────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#1a237e')))
    story.append(Spacer(1, 0.2*cm))

    footer_data = [
        ["Student's Signature", "Examination Controller", "Principal"],
        ["___________________", "___________________", "___________________"],
        ["", "KLP Roorkee", "KLP Roorkee"],
    ]
    footer_table = Table(footer_data, colWidths=[6*cm, 6*cm, 6*cm])
    footer_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(footer_table)
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        "This is a computer-generated marksheet. Official seal required for verification. "
        "For queries, contact: info@klproorkee.edu.in | +91-1332-XXXXXX",
        ParagraphStyle('Footer', parent=styles['Normal'], fontSize=7,
                       alignment=TA_CENTER, textColor=colors.grey)
    ))

    # Build the PDF
    doc.build(story)
    buffer.seek(0)  # Rewind to beginning so Flask can read it
    return buffer
