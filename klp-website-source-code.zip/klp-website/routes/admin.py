"""
Admin panel routes for KLP Roorkee.
Protected by a simple ID/Password login.
Admins can add students, add subjects, and view/delete records.

Access credentials:
  ID       : KLP ROORKEE
  Password : Ubter@12345
"""

from flask import (
    Blueprint, render_template, request,
    redirect, url_for, flash, session
)
from models import Student, Subject
from extensions import db

# Blueprint for admin routes — all URLs start with /admin
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# ─── Hardcoded Admin Credentials ──────────────────────────────────────────────
ADMIN_ID       = "KLP ROORKEE"
ADMIN_PASSWORD = "Ubter@12345"


# ─── Login Required Decorator ─────────────────────────────────────────────────

def admin_required(f):
    """
    Decorator to protect admin routes.
    Redirects to login page if the admin is not logged in.
    """
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('admin_logged_in'):
            flash('Please log in to access the admin panel.', 'warning')
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated


# ─── Admin Login ──────────────────────────────────────────────────────────────

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    """
    GET  → Show the admin login form.
    POST → Validate credentials and log in.
    """
    # If already logged in, go to dashboard
    if session.get('admin_logged_in'):
        return redirect(url_for('admin.dashboard'))

    if request.method == 'POST':
        admin_id  = request.form.get('admin_id', '').strip()
        password  = request.form.get('password', '').strip()

        # Validate credentials (case-sensitive)
        if admin_id == ADMIN_ID and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            flash('Welcome! You are now logged in as Admin.', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Invalid ID or Password. Please try again.', 'danger')

    return render_template('admin_login.html')


# ─── Admin Logout ─────────────────────────────────────────────────────────────

@admin_bp.route('/logout')
def logout():
    """Clear the admin session and redirect to login."""
    session.pop('admin_logged_in', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('admin.login'))


# ─── Admin Dashboard ──────────────────────────────────────────────────────────

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    """
    Main admin dashboard.
    Shows a summary of all students in the database.
    """
    students = Student.query.order_by(Student.created_at.desc()).all()
    total_students = len(students)
    return render_template('admin_dashboard.html', students=students, total_students=total_students)


# ─── Add New Student ──────────────────────────────────────────────────────────

@admin_bp.route('/add-student', methods=['GET', 'POST'])
@admin_required
def add_student():
    """
    GET  → Show the add-student form.
    POST → Validate and save the new student to the database.
    """
    if request.method == 'POST':
        name          = request.form.get('name', '').strip()
        roll_number   = request.form.get('roll_number', '').strip()
        enrollment_no = request.form.get('enrollment_no', '').strip()
        father_name   = request.form.get('father_name', '').strip()
        category      = request.form.get('category', '').strip()
        branch        = request.form.get('branch', '').strip()
        institution   = request.form.get('institution', '').strip()
        semester      = request.form.get('semester', '').strip()
        academic_year = request.form.get('academic_year', '').strip()
        sgpa          = request.form.get('sgpa', '').strip()
        cgpa          = request.form.get('cgpa', '').strip()
        semester_result = request.form.get('semester_result', '').strip()

        # Basic validation
        errors = []
        if not all([name, roll_number, enrollment_no, father_name, category, branch, institution, semester, academic_year]):
            errors.append('All required fields must be filled.')
        if Student.query.filter_by(roll_number=roll_number).first():
            errors.append(f'Roll Number {roll_number} already exists.')
        if Student.query.filter_by(enrollment_no=enrollment_no).first():
            errors.append(f'Enrollment Number {enrollment_no} already exists.')

        if errors:
            for e in errors:
                flash(e, 'danger')
            return render_template('admin_add_student.html')

        # Create and save new student record
        student = Student(
            name=name,
            roll_number=roll_number,
            enrollment_no=enrollment_no,
            father_name=father_name,
            category=category,
            branch=branch,
            institution=institution,
            semester=int(semester),
            academic_year=academic_year,
            sgpa=float(sgpa) if sgpa else None,
            cgpa=float(cgpa) if cgpa else None,
            semester_result=semester_result or None
        )
        db.session.add(student)
        db.session.commit()

        flash(f'Student "{name}" added successfully! Now add their subjects.', 'success')
        return redirect(url_for('admin.add_subjects', student_id=student.id))

    return render_template('admin_add_student.html')


# ─── Add Subjects for a Student ───────────────────────────────────────────────

@admin_bp.route('/add-subjects/<int:student_id>', methods=['GET', 'POST'])
@admin_required
def add_subjects(student_id):
    """
    GET  → Show the add-subjects form for a student.
    POST → Save all submitted subjects (theory + practical, no limit).
    """
    student = Student.query.get_or_404(student_id)

    if request.method == 'POST':
        # Collect all subject entries submitted via the dynamic form
        # The form uses indexed field names: subject_code_0, subject_name_0, etc.
        subject_codes    = request.form.getlist('subject_code')
        subject_names    = request.form.getlist('subject_name')
        subject_types    = request.form.getlist('subject_type')
        max_marks_list   = request.form.getlist('max_marks')
        marks_obtained_list = request.form.getlist('marks_obtained')
        grades           = request.form.getlist('grade')
        results          = request.form.getlist('result')

        # Add each subject row to the database
        subjects_added = 0
        for i in range(len(subject_codes)):
            code = subject_codes[i].strip()
            name = subject_names[i].strip()
            if not code or not name:
                continue  # Skip empty rows

            subj = Subject(
                student_id=student.id,
                subject_code=code,
                subject_name=name,
                subject_type=subject_types[i] if i < len(subject_types) else 'Theory',
                max_marks=int(max_marks_list[i]) if i < len(max_marks_list) and max_marks_list[i] else 0,
                marks_obtained=int(marks_obtained_list[i]) if i < len(marks_obtained_list) and marks_obtained_list[i] else 0,
                grade=grades[i].strip() if i < len(grades) else None,
                result=results[i].strip() if i < len(results) else None,
            )
            db.session.add(subj)
            subjects_added += 1

        db.session.commit()
        flash(f'{subjects_added} subject(s) added for {student.name}.', 'success')
        return redirect(url_for('admin.view_student', student_id=student.id))

    # GET — show the form with existing subjects (for reference)
    existing_subjects = student.subjects
    return render_template('admin_add_subjects.html', student=student, existing_subjects=existing_subjects)


# ─── View Student Detail ──────────────────────────────────────────────────────

@admin_bp.route('/student/<int:student_id>')
@admin_required
def view_student(student_id):
    """Show full details of a student, including all their subjects."""
    student = Student.query.get_or_404(student_id)
    theory_subjects    = [s for s in student.subjects if s.subject_type == 'Theory']
    practical_subjects = [s for s in student.subjects if s.subject_type == 'Practical']
    return render_template(
        'admin_view_student.html',
        student=student,
        theory_subjects=theory_subjects,
        practical_subjects=practical_subjects
    )


# ─── Edit Student ─────────────────────────────────────────────────────────────

@admin_bp.route('/edit-student/<int:student_id>', methods=['GET', 'POST'])
@admin_required
def edit_student(student_id):
    """Edit a student's personal and academic details."""
    student = Student.query.get_or_404(student_id)

    if request.method == 'POST':
        student.name          = request.form.get('name', student.name).strip()
        student.roll_number   = request.form.get('roll_number', student.roll_number).strip()
        student.enrollment_no = request.form.get('enrollment_no', student.enrollment_no).strip()
        student.father_name   = request.form.get('father_name', student.father_name).strip()
        student.category      = request.form.get('category', student.category).strip()
        student.branch        = request.form.get('branch', student.branch).strip()
        student.institution   = request.form.get('institution', student.institution).strip()
        student.semester      = int(request.form.get('semester', student.semester))
        student.academic_year = request.form.get('academic_year', student.academic_year).strip()
        sgpa = request.form.get('sgpa', '').strip()
        cgpa = request.form.get('cgpa', '').strip()
        student.sgpa          = float(sgpa) if sgpa else None
        student.cgpa          = float(cgpa) if cgpa else None
        student.semester_result = request.form.get('semester_result', student.semester_result).strip()
        db.session.commit()
        flash('Student details updated successfully!', 'success')
        return redirect(url_for('admin.view_student', student_id=student.id))

    return render_template('admin_add_student.html', student=student, editing=True)


# ─── Delete Student ───────────────────────────────────────────────────────────

@admin_bp.route('/delete-student/<int:student_id>', methods=['POST'])
@admin_required
def delete_student(student_id):
    """Delete a student and all their subjects (cascade delete)."""
    student = Student.query.get_or_404(student_id)
    name = student.name
    db.session.delete(student)
    db.session.commit()
    flash(f'Student "{name}" and all related data deleted.', 'warning')
    return redirect(url_for('admin.dashboard'))


# ─── Delete Single Subject ────────────────────────────────────────────────────

@admin_bp.route('/delete-subject/<int:subject_id>', methods=['POST'])
@admin_required
def delete_subject(subject_id):
    """Delete a single subject from a student's record."""
    subject = Subject.query.get_or_404(subject_id)
    student_id = subject.student_id
    db.session.delete(subject)
    db.session.commit()
    flash(f'Subject "{subject.subject_name}" deleted.', 'warning')
    return redirect(url_for('admin.view_student', student_id=student_id))
